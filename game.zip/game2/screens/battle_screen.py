from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.graphics import Color, RoundedRectangle
from kivy.properties import ObjectProperty, ListProperty, NumericProperty
from kivy.app import App
import random

Builder.load_file("screens/battle_screen.kv")

RARITY_COLORS = {
  "common": [0.8, 0.8, 0.8, 1],
  "uncommon": [0.5, 1, 0.5, 1],
  "rare": [0.5, 0.5, 1, 1],
  "epic": [0.8, 0.5, 1, 1],
  "legendary": [1, 0.8, 0.3, 1],
}

class BattleScreen(Screen):
    turn_index = NumericProperty(0)
    players = ListProperty([])
    boss = ObjectProperty(None)
    phase = "hero"
    
    def on_enter(self):
        gm = App.get_running_app().manager
        self.players = gm.player_team
        self.boss = gm.boss
        self.turn_index = 0
        if not gm.round_number or gm.round_number >= 1:
            gm.round_number = gm.next_round()  # satu putaran semua hero + boss 
            self.ids.turn_info.text = f"Turn info will be shown here"
        self.phase = "hero"

        self.render_layout()

    def render_layout(self):
        self.ids.hero_box.clear_widgets()
        self.ids.boss_box.clear_widgets()
        self.ids.action_panel.clear_widgets()
        self.ids.submenu_box.clear_widgets()

        # Boss UI
        boss_color = RARITY_COLORS.get(self.boss.special_skill.rarity, [0.3, 0.3, 0.3, 1])
        boss_box = BoxLayout(orientation='vertical', padding=5, spacing=5)

        with boss_box.canvas.before:
            Color(*boss_color)
            self.boss_bg = RoundedRectangle(pos=boss_box.pos, size=boss_box.size, radius=[8])
        boss_box.bind(pos=self._update_bg(self.boss_bg), size=self._update_bg(self.boss_bg))

        boss_btn = Button(text=self.boss.name, font_size=22, bold=True, on_release=lambda inst:
        self.show_boss_popup(self.boss))        
        # boss_box.add_widget(Label(text=self.boss.name, font_size=22, bold=True))
        boss_box.add_widget(boss_btn)
        boss_box.add_widget(Label(text=f"Class: {self.boss.__class__.__name__}"))
        boss_box.add_widget(Label(text=f"HP: {self.boss.hp}/{self.boss.max_hp}"))
        boss_box.add_widget(Label(text=f"MP: {self.boss.mp}/{self.boss.max_mp}"))
        self.ids.boss_box.add_widget(boss_box)

        # Hero List
        for hero in self.players:
            rarity = hero.special_skill.rarity if hero.special_skill else "common"
            hero_color = RARITY_COLORS.get(rarity, [0.5, 0.5, 0.5, 1])
            box = BoxLayout(orientation='vertical', padding=5, spacing=3, size_hint_y=None, height=150)

            with box.canvas.before:
                Color(*hero_color)
                bg = RoundedRectangle(pos=box.pos, size=box.size, radius=[8])
            box.bind(pos=self._update_bg(bg), size=self._update_bg(bg))

            btn = Button(text=hero.name, bold=True)
            btn.bind(on_release=lambda inst, h=hero: self.show_player_popup(h))
            box.add_widget(btn)
            box.add_widget(Label(text=f"ATK: {hero.atk}", font_size=22))
            box.add_widget(Label(text=f"HP: {hero.hp}/{hero.max_hp}", font_size=22))
            box.add_widget(Label(text=f"MP: {hero.mp}/{hero.max_mp}", font_size=22))
            self.ids.hero_box.add_widget(box)

        gm = App.get_running_app().manager
        self.ids.turn_label.text = f"Turn {gm.round_number}"

        self.update_turn()

    def update_status_boxes(self):
        # Hapus dan render ulang hero dan boss box tanpa reset turn
        self.ids.hero_box.clear_widgets()
        self.ids.boss_box.clear_widgets()

        # Boss box
        boss_color = RARITY_COLORS.get(self.boss.special_skill.rarity, [0.3, 0.3, 0.3, 1])
        boss_box = BoxLayout(orientation='vertical', padding=5, spacing=5)

        with boss_box.canvas.before:
            Color(*boss_color)
            self.boss_bg = RoundedRectangle(pos=boss_box.pos, size=boss_box.size, radius=[8])
        boss_box.bind(pos=self._update_bg(self.boss_bg), size=self._update_bg(self.boss_bg))

        boss_btn = Button(text=self.boss.name, font_size=22, bold=True,
                          on_release=lambda inst: self.show_boss_popup(self.boss))
        boss_box.add_widget(boss_btn)
        boss_box.add_widget(Label(text=f"Class: {self.boss.__class__.__name__}"))
        boss_box.add_widget(Label(text=f"HP: {self.boss.hp}/{self.boss.max_hp}"))
        boss_box.add_widget(Label(text=f"MP: {self.boss.mp}/{self.boss.max_mp}"))
        self.ids.boss_box.add_widget(boss_box)

        # Hero boxes
        for i, hero in enumerate(self.players):
            rarity = hero.special_skill.rarity if hero.special_skill else "common"
            hero_color = RARITY_COLORS.get(rarity, [0.5, 0.5, 0.5, 1])
            highlight_color = [1, 1, 1, 1]

            # Jika hero ini adalah yang sedang mendapat giliran
            if self.phase == "hero" and i == self.turn_index:
                # Tambahkan highlight — misal: warna sedikit lebih terang atau border
                hero_color = [c + 0.2 if c < 0.8 else 1 for c in hero_color]  # highlight
                highlight_color = [0, 0, 0, 1]


            box = BoxLayout(orientation='vertical', padding=5, spacing=3, size_hint_y=None, height=150)

            with box.canvas.before:
                Color(*hero_color)
                bg = RoundedRectangle(pos=box.pos, size=box.size, radius=[8])
            box.bind(pos=self._update_bg(bg), size=self._update_bg(bg))

            btn = Button(text=hero.name, bold=True, color=highlight_color)
            btn.bind(on_release=lambda inst, h=hero: self.show_player_popup(h))
            box.add_widget(btn)
            box.add_widget(Label(text=f"ATK: {hero.atk}", font_size=22, color=highlight_color))
            box.add_widget(Label(text=f"HP: {hero.hp}/{hero.max_hp}", font_size=22, color=highlight_color))
            box.add_widget(Label(text=f"MP: {hero.mp}/{hero.max_mp}", font_size=22, color=highlight_color))

            self.ids.hero_box.add_widget(box)

    def _update_bg(self, rect):
        def update(instance, value):
            rect.pos = instance.pos
            rect.size = instance.size
        return update

    def update_turn(self):
        if self.phase == "hero":
            while self.turn_index < len(self.players):
                hero = self.players[self.turn_index]
                if hero.is_alive() and not hero.escaped:
                    gm = App.get_running_app().manager
                    self.ids.turn_label.text = f"Turn {gm.round_number}"
                    # self.ids.turn_info.text = f"Turn {hero.name}"
                    self.show_action_options(hero)
                    self.update_status_boxes()
                    return  # hanya tampilkan jika valid
                else:
                    self.turn_index += 1  # lewati hero mati/kabur

            # Kalau semua hero selesai → boss turn
            self.phase = "boss"
            self.update_turn()

        elif self.phase == "boss":
            gm = App.get_running_app().manager
            self.ids.turn_label.text = f"Turn {gm.round_number}"
            self.ids.turn_info.text = f"Turn {self.boss.name}"
            self.do_boss_turn()
            # btn = Button(text="Next", background_color=(0.4, 0.9, 0.4, 1))
            # btn.bind(on_release=self.go_to_shop)
            # self.ids.action_panel.clear_widgets()
            # self.ids.action_panel.add_widget(btn)

    def show_action_options(self, hero):
        self.ids.action_panel.clear_widgets()
        self.ids.submenu_box.clear_widgets()

        actions = [
            ("Attack", self.do_attack),
            ("Skills", self.show_skills),
            ("Special", self.show_special),
            ("Restore MP", self.restore_mp),
            ("Retreat", self.retreat)
        ]
        for name, func in actions:
            btn = Button(text=name, background_color=(0.6, 0.6, 0.9, 1))
            btn.bind(on_release=lambda inst, f=func: f(hero))
            self.ids.action_panel.add_widget(btn)

    def show_skills(self, hero):
        self.ids.submenu_box.clear_widgets()
        self.ids.submenu_box.add_widget(Button(text="Back", on_release=lambda x: self.show_action_options(hero)))
        for skill in hero.skills:
            color = RARITY_COLORS.get(skill.rarity, [0.5, 0.5, 0.5, 1])
            btn = Button(text=skill.name, background_color=color)
            btn.bind(on_release=lambda inst, s=skill: self.use_skill(hero, s))
            self.ids.submenu_box.add_widget(btn)

    def show_special(self, hero):
        self.ids.submenu_box.clear_widgets()
        self.ids.submenu_box.add_widget(Button(text="Back", on_release=lambda x: self.show_action_options(hero)))
        skill = hero.special_skill
        if skill:
            color = RARITY_COLORS.get(skill.rarity, [0.5, 0.5, 0.5, 1])
            btn = Button(text=skill.name, background_color=color)
            btn.bind(on_release=lambda inst: self.use_special(hero, skill))
            self.ids.submenu_box.add_widget(btn)

    def use_skill(self, hero, skill):
        if hero.mp < skill.mp_cost:
            self.ids.turn_info.text = f"{hero.name} tidak punya cukup MP untuk {skill.name}!"
            return

        # Tentukan target berdasarkan skill type & target_type
        if skill.target_type == "multi":
            targets = self.players if skill.type in ("healing", "buff") else [self.boss]
        elif skill.target_type == "single":
            targets = [hero] if skill.type in ("healing", "buff") else [self.boss]
        else:
            targets = [hero]  # fallback

        hero.use_skill(skill, targets)
        
        boss = App.get_running_app().manager.boss
        desc = ""
        if skill.type == "atk":
            desc = f"atk boss for {skill.power - boss.defense}"
        elif skill.type == "healing":
            if skill.target_type == "multi":
              desc = f"all hero heal for {skill.power}"
            else:
              desc = f"heal self for {skill.power}"
        elif skill.type == "buff":
            amt = skill.power if skill.power > 0 else int(hero.atk * 0.2)
            hero.atk += amt
            if skill.target_type == "multi":
              desc = f"all hero atk increased by {amt}"
            else:
              desc = f"atk increased by {amt}"
        elif skill.type == "debuff":
            amt = skill.power if skill.power > 0 else int(hero.atk * 0.2)
            hero.defense = max(0, hero.defense - amt)
            desc = f"def increased by {amt}"
            
        # Deskripsi aksi
        self.ids.turn_info.text = f"Turn {hero.name}: Skill {skill.name} ({skill.mp_cost} mp)! \n{desc}"
        self.update_status_boxes()
        self.advance_turn()


    def use_special(self, hero, special):
        # Cek MP cukup
        if hero.mp < special.mp_cost:
            self.ids.turn_info.text = f"{hero.name} tidak punya cukup MP untuk {special.name}!"
            return

        # Tentukan target berdasarkan tipe
        if special.target_type == "multi":
            targets = self.players if special.type in ("healing", "buff") else [self.boss]
        elif special.target_type == "single":
            targets = [hero] if special.type in ("healing", "buff") else [self.boss]
        else:
            targets = [hero]  # fallback default ke self

        # Gunakan skill
        hero.use_special_skill(targets)
        
        boss = App.get_running_app().manager.boss
        desc = ""
        if special.type == "atk":
            desc = f"atk boss for {special.power - boss.defense}"
        elif special.type == "healing":
            if special.target_type == "multi":
              desc = f"all hero heal for {special.power}"
            else:
              desc = f"heal self for {special.power}"
        elif special.type == "buff":
            amt = special.power if special.power > 0 else int(hero.atk * 0.2)
            hero.atk += amt
            if special.target_type == "multi":
              desc = f"all hero atk increased by {amt}"
            else:
              desc = f"atk increased by {amt}"
        elif special.type == "debuff":
            amt = special.power if special.power > 0 else int(hero.atk * 0.2)
            hero.defense = max(0, hero.defense - amt)
            desc = f"def increased by {amt}"
                
        # Deskripsi aksi
        self.ids.turn_info.text = f"Turn {hero.name}: special {special.name} ({special.mp_cost} mp)! \n{desc}"
        self.update_status_boxes()
        self.advance_turn()

    def do_attack(self, hero):
        boss = App.get_running_app().manager.boss
        hero.attack_target(boss)

        damage = hero.atk - boss.defense
        damage = damage if damage > 0 else 1

        self.ids.turn_info.text = f"Turn {hero.name}: Attack {damage} ke {boss.name}"
        self.update_status_boxes()  # <--- ini penting
        self.advance_turn()

    def restore_mp(self, hero):
        hero.restore_mp()
        self.ids.turn_info.text = f"Turn {hero.name}: Memulihkan MP ke {hero.mp}/{hero.max_mp}"
        self.update_status_boxes()
        self.advance_turn()

    def retreat(self, hero):
        hero.retreat()

        self.ids.turn_info.text = f"{hero.name} retreats from battle!"
        self.update_status_boxes()
        

        if all(not h.is_alive() or h.escaped for h in self.players):
            self.ids.turn_info.text = "☠️ Semua hero tumbang."
            self.ids.action_panel.clear_widgets()
            self.ids.submenu_box.clear_widgets()
            self.show_end_popup("☠️ Better luck next time...", "Kekalahan")
            return

        self.advance_turn()

    def do_boss_turn(self):
        alive_targets = [p for p in self.players if p.is_alive() and not p.escaped]
        if not alive_targets:
            self.ids.turn_info.text = "☠️ Semua hero gugur. Boss menang!"
            self.game_over()
            return
          
        if not self.boss.is_alive():
            self.ids.turn_info.text = "🏆 Victory! Boss dikalahkan."
            self.ids.action_panel.clear_widgets()
            self.ids.submenu_box.clear_widgets()
            self.show_end_popup("🏆 Selamat! Anda menang!", "Kemenangan")
            return True

        choice = random.randint(1, 100)

        if choice <= 30:
            # Basic Attack
            target = random.choice(alive_targets)
            self.boss.attack(target)

            damage = self.boss.atk - target.defense
            damage = damage if damage > 0 else 1
            self.ids.turn_info.text = f"Turn {self.boss.name}: Attack {damage} ke {target.name}"

        elif choice <= 80:
            # Use Skill
            skill = random.choice(self.boss.skills)
            if self.boss.mp >= skill.mp_cost:
                if skill.type == "healing":
                    targets =  [self.boss]
                elif skill.target_type == "multi":
                    targets = alive_targets
                elif skill.target_type == "single":
                    targets = [random.choice(alive_targets)]
                else:
                    targets = [self.boss]

                skill.use(self.boss, targets)
                
                desc = ""
                if skill.type == "atk":
                    if skill.target_type == "multi":
                      desc = f"atk all hero for {skill.power}"
                    else:
                      desc = f"atk {targets[0].name} for {skill.power - targets[0].defense}"
                elif skill.type == "healing":
                    if skill.target_type == "multi":
                      desc = f"heal self  for {skill.power}"
                    else:
                      desc = f"heal self for {skill.power}"
                elif skill.type == "buff":
                    amt = skill.power if skill.power > 0 else int(self.boss.atk * 0.2)
                    self.boss.atk += amt
                    if skill.target_type == "multi":
                      desc = f"atk increased by {amt}"
                    else:
                      desc = f"atk increased by {amt}"
                elif skill.type == "debuff":
                    amt = skill.power if skill.power > 0 else int(self.boss.atk * 0.2)
                    self.boss.defense = max(0, skill.defense - amt)
                    desc = f"def increased by {amt}"
                        
                self.ids.turn_info.text = f"Turn {self.boss.name}: Skill {skill.name}! ({skill.mp_cost} mp)! \n{desc}"
# self.ids.turn_info.text = f"Turn {hero.name}: special {special.name} ({special.mp_cost} mp)! \n{desc}"

            else:
                self.boss.restore_mp()
                self.ids.turn_info.text = f"{self.boss.name} memulihkan MP-nya!"

        else:
            # Use Special Skill
            ss = self.boss.special_skill
            if self.boss.mp >= ss.mp_cost:
                if ss.type == "healing":
                    targets = [self.boss]
                elif ss.target_type == "multi":
                    targets = alive_targets
                elif ss.target_type == "single":
                    targets = [random.choice(alive_targets)]
                else:
                    targets = [self.boss]

                ss.use(self.boss, targets)
                
                desc = ""
                if ss.type == "atk":
                    if ss.target_type == "multi":
                      desc = f"atk all hero for {ss.power}"
                    else:
                      desc = f"atk {targets[0].name} for {ss.power - targets[0].defense}"
                elif ss.type == "healing":
                    if ss.target_type == "multi":
                      desc = f"heal self  for {ss.power}"
                    else:
                      desc = f"heal self for {ss.power}"
                elif ss.type == "buff":
                    amt = ss.power if ss.power > 0 else int(self.boss.atk * 0.2)
                    self.boss.atk += amt
                    if ss.target_type == "multi":
                      desc = f"atk increased by {amt}"
                    else:
                      desc = f"atk increased by {amt}"
                elif ss.type == "debuff":
                    amt = ss.power if ss.power > 0 else int(self.boss.atk * 0.2)
                    self.boss.defense = max(0, ss.defense - amt)
                    desc = f"def increased by {amt}"
                        
                self.ids.turn_info.text = f"Turn {self.boss.name}: special {ss.name}! ({ss.mp_cost} mp)! \n{desc}"
                # self.ids.turn_info.text = f"Turn {self.boss.name}: Special Skill {ss.name}!"
            else:
                self.boss.restore_mp()
                self.ids.turn_info.text = f"{self.boss.name} memulihkan MP-nya!"

        self.update_status_boxes()
        self.advance_turn()

    def advance_turn(self):
        if self.phase == "hero":
            self.turn_index += 1
            self.update_turn()
        elif self.phase == "boss":
            # gm = App.get_running_app().manager
            # self.round_number = gm.next_round()

            btn = Button(text="Next", background_color=(0.4, 0.9, 0.4, 1))
            btn.bind(on_release=self.go_to_shop)
            self.ids.action_panel.clear_widgets()
            self.ids.submenu_box.clear_widgets()
            self.ids.action_panel.add_widget(btn)
            
        self.game_over()

            # self.round_number += 1
            # self.turn_index = 0
            # self.phase = "hero"
            # self.update_turn()

    def game_over(self):
        # Cek apakah boss sudah kalah
        if not self.boss.is_alive():
            self.ids.turn_info.text = "🏆 Victory! Boss dikalahkan."
            self.ids.action_panel.clear_widgets()
            self.ids.submenu_box.clear_widgets()
            self.show_end_popup("🏆 Selamat! Anda menang!", "Kemenangan")
            return True

        if all(not h.is_alive() or h.escaped for h in self.players):
            self.ids.turn_info.text = "☠️ Semua hero tumbang."
            self.ids.action_panel.clear_widgets()
            self.ids.submenu_box.clear_widgets()
            self.show_end_popup("☠️ Better luck next time...", "Kekalahan")
            return True

        return False  # game masih berjalan

    # def next_turn(self, instance):
    #     self.turn_index = 0
    #     self.phase = "hero"
    #     self.update_turn()
        
    def go_to_shop(self, instance):
        gm = App.get_running_app().manager
        gm.create_shop()
        gm.give_income()
        self.turn_index = 0
        self.phase = "hero"
        self.manager.current = "shop_screen"

    def show_boss_popup(self, boss):
        # print(boss)
        content = BoxLayout(orientation="vertical", padding=10, spacing=5)
        info = f"[b]{boss.name}[/b]\n"
        info += f"Class: {boss.hero_class}\n"
        info += f"Type: {boss.special_skill.rarity if boss.special_skill else '-'}\n\n"
        info += f"HP: {boss.hp}/{boss.max_hp}\n"
        info += f"MP: {boss.mp}/{boss.max_mp}\n"
        info += f"ATK: {boss.atk}\n"
        info += f"DEF: {boss.defense}\n\n"

        skill_names = ', '.join([s.name for s in boss.skills]) if boss.skills else "-"
        info += f"Skills: {skill_names}\n\n"
        info += f"Special Skill: {boss.special_skill.name if boss.special_skill else '-'}"

        label = Label(text=info, markup=True)
        content.add_widget(label)

        popup = Popup(title="Boss Info", content=content, size_hint=(0.6, 0.6))
        popup.open()

    def show_player_popup(self, player):
        content = BoxLayout(orientation='vertical', padding=10, spacing=5)
        info = f"[b]{player.name}[/b]\n"
        # info += f"Class: {getattr(player, 'char_class', {player.hero_class})}\n"
        info += f"Class: {player.hero_class}\n"
        info += f"Type: {player.special_skill.rarity if player.special_skill else '-'}\n\n"
        info += f"HP: {player.hp}/{player.max_hp}\n"
        info += f"MP: {player.mp}/{player.max_mp}\n"
        info += f"ATK: {player.atk}\n"
        info += f"DEF: {player.defense}\n\n"

        # skills
        skill_names = ', '.join([s.name for s in player.skills]) if player.skills else "-"
        info += f"Skills: {skill_names}\n\n"

        # special
        info += f"Special Skill: {player.special_skill.name if player.special_skill else '-'}\n\n"

        # items
        if hasattr(player, "equipped_items") and player.equipped_items:
            item_names = ', '.join([item.name for item in player.equipped_items])
            info += f"Items: {item_names}"
        else:
            info += "Items: -"

        label = Label(text=info, markup=True)
        content.add_widget(label)

        popup = Popup(title="Player Info", content=content, size_hint=(0.6, 0.7))
        popup.open()

    def show_end_popup(self, message, title="Game Over"):
        content = BoxLayout(orientation='vertical', spacing=10, padding=20)
        content.add_widget(Label(text=message, font_size=32))

        btn = Button(text="OK", size_hint_y=None, height=40)
        content.add_widget(btn)

        popup = Popup(title=title, content=content, size_hint=(None, None), size=(400, 300), auto_dismiss=False)
        btn.bind(on_release=lambda instance: self.end_game(popup))
        popup.open()
        
    def end_game(self, popup):
        popup.dismiss()
        
        gm = App.get_running_app().manager
        gm.round_number = gm.new_round()
        
        self.manager.current = "main_menu"
