from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.app import App

Builder.load_file("screens/main_menu.kv")

class MainMenuScreen(Screen):
  def on_enter(self):
    App.get_running_app().play_music("assets/sound/the_path_of_the_goblin_king.mp3")
    
  def on_play(self):
    app = App.get_running_app()
    app.manager.init_skills_and_items()
    app.manager.create_heroes_and_bosses()

    # Ganti musik
    app.play_music("assets/sound/dream_culture.mp3")

    self.manager.current = "hero_result"

  def on_exit(self):
    App.get_running_app().stop()
